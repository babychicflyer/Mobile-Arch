package com.zybooks.reinersmaninventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private List<InventoryItem> inventoryList = new ArrayList<>();
    private InventoryAdapter adapter;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);

        ListView listViewInventory = findViewById(R.id.listViewInventory);
        EditText editTextItemName = findViewById(R.id.editTextItemName);
        EditText editTextQuantity = findViewById(R.id.editTextQuantity);
        Button buttonAddItem = findViewById(R.id.buttonAddItem);
        Button buttonSmsSettings = findViewById(R.id.buttonSmsSettings);

        adapter = new InventoryAdapter(this, inventoryList, databaseHelper, this::loadInventoryData);
        listViewInventory.setAdapter(adapter);

        loadInventoryData();

        buttonAddItem.setOnClickListener(v -> {
            String itemName = editTextItemName.getText().toString().trim();
            String quantityStr = editTextQuantity.getText().toString().trim();

            if (itemName.isEmpty() || quantityStr.isEmpty()) {
                Toast.makeText(this, "Please enter item name and quantity", Toast.LENGTH_SHORT).show();
            } else {
                int quantity = Integer.parseInt(quantityStr);
                databaseHelper.addItem(itemName, quantity);
                loadInventoryData();
                
                if (quantity == 0) {
                    Toast.makeText(this, itemName + " is out of stock!", Toast.LENGTH_LONG).show();
                    // Trigger SMS alert if permission is granted
                    SmsService.sendLowStockAlert(this, itemName);
                }
                
                editTextItemName.setText("");
                editTextQuantity.setText("");
            }
        });

        buttonSmsSettings.setOnClickListener(v -> {
            Intent intent = new Intent(this, SmsActivity.class);
            startActivity(intent);
        });
    }

    private void loadInventoryData() {
        inventoryList.clear();
        Cursor cursor = databaseHelper.getAllItems();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_NAME));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ITEM_QUANTITY));
                inventoryList.add(new InventoryItem(id, name, quantity));
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }
}
