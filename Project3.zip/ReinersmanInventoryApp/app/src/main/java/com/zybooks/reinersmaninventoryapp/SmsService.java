package com.zybooks.reinersmaninventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.content.ContextCompat;

public class SmsService {

    public static void sendLowStockAlert(Context context, String itemName) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) 
                == PackageManager.PERMISSION_GRANTED) {
            
            try {
                SmsManager smsManager = SmsManager.getDefault();
                // Using a dummy number for demonstration. In a real app, this might be a saved preference.
                String phoneNumber = "5551234567"; 
                String message = "ALERT: Inventory for " + itemName + " is out of stock!";
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
