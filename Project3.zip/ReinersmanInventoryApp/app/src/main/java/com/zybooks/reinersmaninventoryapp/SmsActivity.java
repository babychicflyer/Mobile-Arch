package com.zybooks.reinersmaninventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        Button buttonAllowSms = findViewById(R.id.buttonAllowSms);
        Button buttonDenySms = findViewById(R.id.buttonDenySms);
        TextView textSmsStatus = findViewById(R.id.textSmsStatus);

        buttonAllowSms.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
            } else {
                textSmsStatus.setText("SMS notifications are enabled!");
            }
        });

        buttonDenySms.setOnClickListener(v -> {
            textSmsStatus.setText("SMS notifications are disabled. App will continue without notifications.");
            Toast.makeText(this, "SMS notifications disabled", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        TextView textSmsStatus = findViewById(R.id.textSmsStatus);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                textSmsStatus.setText("SMS notifications are enabled!");
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                textSmsStatus.setText("SMS permission denied. Notifications will not be sent.");
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}