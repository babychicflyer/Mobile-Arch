package com.zybooks.reinersmaninventoryapp;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.List;

public class InventoryAdapter extends BaseAdapter {

    private Context context;
    private List<InventoryItem> inventoryItems;
    private DatabaseHelper databaseHelper;
    private OnItemDeletedListener deleteListener;

    public interface OnItemDeletedListener {
        void onItemDeleted();
    }

    public InventoryAdapter(Context context, List<InventoryItem> inventoryItems, DatabaseHelper databaseHelper, OnItemDeletedListener deleteListener) {
        this.context = context;
        this.inventoryItems = inventoryItems;
        this.databaseHelper = databaseHelper;
        this.deleteListener = deleteListener;
    }

    @Override
    public int getCount() {
        return inventoryItems.size();
    }

    @Override
    public Object getItem(int position) {
        return inventoryItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return inventoryItems.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.inventory_item, parent, false);
        }

        InventoryItem item = inventoryItems.get(position);

        TextView textViewName = convertView.findViewById(R.id.textViewName);
        EditText editTextQuantity = convertView.findViewById(R.id.editTextQuantity);
        Button buttonDelete = convertView.findViewById(R.id.buttonDelete);

        textViewName.setText(item.getName());
        editTextQuantity.setText(String.valueOf(item.getQuantity()));

        // Update functionality
        editTextQuantity.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                String qtyStr = editTextQuantity.getText().toString();
                if (!qtyStr.isEmpty()) {
                    int newQty = Integer.parseInt(qtyStr);
                    if (newQty != item.getQuantity()) {
                        item.setQuantity(newQty);
                        databaseHelper.updateItem(item.getId(), item.getName(), item.getQuantity());
                    }
                }
            }
        });

        // Delete functionality
        buttonDelete.setOnClickListener(v -> {
            databaseHelper.deleteItem(item.getId());
            if (deleteListener != null) {
                deleteListener.onItemDeleted();
            }
        });

        return convertView;
    }
}
